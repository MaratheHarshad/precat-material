// class object
// inline fun
// default argrument
// size of empty class object
// cin and cout
// this pointer
// types of member function complex class 

//const in c and cpp
// reference
//swap using ref
//exception handling
//friend demo
