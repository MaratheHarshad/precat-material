//day3
	// const data member, member fun and object

// static data member and static member functions
// dynamic memory allocation
//  	//operator overloading 
//       Array class



// OPPS concepts
// composition 
	// demo of person
            // date class
            // address class
            //person class				
// inheritance
//       types of inherittnace



