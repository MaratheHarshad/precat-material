/*
int *ptr= (int*)malloc(1*sizeof(int));  // c  malloc is a function
int *ptr=new int; new is operator

*/