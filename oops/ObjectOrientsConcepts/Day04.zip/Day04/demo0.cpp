


// day4
// inheritance
//       modes of inherittnace
	// demo of employee class
//1. diamond problem and its solution no1 
 // diamond problem and its solution no2 virtual inheritance


//2. object slicing
//3. casting upcasting /downcasting
//4. virtual function / pure virtual function


//5. function overriding
//6. RTTI

// template for function 
// template for class
// copy ctor -shallow copy deep copy
// casting operators

// Multiple files demo

